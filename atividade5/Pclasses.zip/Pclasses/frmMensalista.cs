﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void BtnMensalista1_Click(object sender, EventArgs e)
        {
            // cria ou instanciar o objeto da classe mensalista
            Mensalista objMensalista = new Mensalista();

            //set
            objMensalista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objMensalista.NomeEmpregado = TxtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(TxtData.Text);//dd/mm/yyyy
            objMensalista.SalarioMensal = Convert.ToDouble(TxtSalario.Text);

            //get
            MessageBox.Show("Matrícula              : " + objMensalista.Matricula + "\n" +
                            "Nome                   : " + objMensalista.NomeEmpregado + "\n" +
                            "Data Entrada           : " + objMensalista.DataEntradaEmpresa.ToShortDateString() +
                             "\n" +
                            "Salário Bruto          : " + objMensalista.SalarioBruto().ToString("n2") + "\n" +
                            "Tempo Empresa (Dias)   : " + objMensalista.TempoTrabalho());

                            
        }

        private void BtnMensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(TxtMatricula.Text),
               TxtNome.Text, Convert.ToDateTime(TxtData.Text), Convert.ToDouble(TxtSalario.Text));

            //get

            MessageBox.Show("Matrícula: " + objMensalista.Matricula + "\n" +
                           "Nome: " + objMensalista.NomeEmpregado + "\n" +
                           "Data Entrada: " + objMensalista.DataEntradaEmpresa.ToShortDateString() +
                            "\n" +
                           "Salário Bruto: " + objMensalista.SalarioBruto().ToString("n2") + "\n" +
                           "Tempo Empresa (Dias): " + objMensalista.TempoTrabalho());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorsita : Form
    {
        public frmHorsita()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();


            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);//dd/mm/yyyy
            objHorista.SalarioHora = Convert.ToDouble(txtSalarioHora.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFalta.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroHoras.Text);

            MessageBox.Show("Matrícula: " + objHorista.Matricula + "\n" +
                           "Nome: " + objHorista.NomeEmpregado + "\n" +
                           "Salário: " + objHorista.SalarioBruto().ToString("n2") + "\n" +
                           "Tempo Trabalho (Dias): " + objHorista.TempoTrabalho());

        }
    }
}

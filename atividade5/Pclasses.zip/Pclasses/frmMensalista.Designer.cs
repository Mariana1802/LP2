﻿
namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMatricula = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalario = new System.Windows.Forms.Label();
            this.LblData = new System.Windows.Forms.Label();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtSalario = new System.Windows.Forms.TextBox();
            this.TxtData = new System.Windows.Forms.TextBox();
            this.BtnMensalista1 = new System.Windows.Forms.Button();
            this.BtnMensalista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Location = new System.Drawing.Point(40, 27);
            this.LblMatricula.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(52, 13);
            this.LblMatricula.TabIndex = 0;
            this.LblMatricula.Text = "Matrícula";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(40, 63);
            this.LblNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(35, 13);
            this.LblNome.TabIndex = 1;
            this.LblNome.Text = "Nome";
            // 
            // LblSalario
            // 
            this.LblSalario.AutoSize = true;
            this.LblSalario.Location = new System.Drawing.Point(40, 102);
            this.LblSalario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblSalario.Name = "LblSalario";
            this.LblSalario.Size = new System.Drawing.Size(76, 13);
            this.LblSalario.TabIndex = 2;
            this.LblSalario.Text = "Salário Mensal";
            // 
            // LblData
            // 
            this.LblData.AutoSize = true;
            this.LblData.Location = new System.Drawing.Point(40, 140);
            this.LblData.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblData.Name = "LblData";
            this.LblData.Size = new System.Drawing.Size(144, 13);
            this.LblData.TabIndex = 3;
            this.LblData.Text = "Data de Entrada na Empresa";
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(326, 27);
            this.TxtMatricula.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(118, 20);
            this.TxtMatricula.TabIndex = 4;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(224, 63);
            this.TxtNome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(220, 20);
            this.TxtNome.TabIndex = 5;
            // 
            // TxtSalario
            // 
            this.TxtSalario.Location = new System.Drawing.Point(224, 99);
            this.TxtSalario.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtSalario.Name = "TxtSalario";
            this.TxtSalario.Size = new System.Drawing.Size(220, 20);
            this.TxtSalario.TabIndex = 6;
            // 
            // TxtData
            // 
            this.TxtData.Location = new System.Drawing.Point(326, 137);
            this.TxtData.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtData.Name = "TxtData";
            this.TxtData.Size = new System.Drawing.Size(118, 20);
            this.TxtData.TabIndex = 7;
            // 
            // BtnMensalista1
            // 
            this.BtnMensalista1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMensalista1.Location = new System.Drawing.Point(42, 214);
            this.BtnMensalista1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnMensalista1.Name = "BtnMensalista1";
            this.BtnMensalista1.Size = new System.Drawing.Size(206, 93);
            this.BtnMensalista1.TabIndex = 8;
            this.BtnMensalista1.Text = "Instanciar Mensalista";
            this.BtnMensalista1.UseVisualStyleBackColor = true;
            this.BtnMensalista1.Click += new System.EventHandler(this.BtnMensalista1_Click);
            // 
            // BtnMensalista
            // 
            this.BtnMensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMensalista.Location = new System.Drawing.Point(278, 214);
            this.BtnMensalista.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnMensalista.Name = "BtnMensalista";
            this.BtnMensalista.Size = new System.Drawing.Size(206, 93);
            this.BtnMensalista.TabIndex = 9;
            this.BtnMensalista.Text = "Instanciar mensalista passando parâmetros";
            this.BtnMensalista.UseVisualStyleBackColor = true;
            this.BtnMensalista.Click += new System.EventHandler(this.BtnMensalista_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.BtnMensalista);
            this.Controls.Add(this.BtnMensalista1);
            this.Controls.Add(this.TxtData);
            this.Controls.Add(this.TxtSalario);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.LblData);
            this.Controls.Add(this.LblSalario);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.LblMatricula);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalario;
        private System.Windows.Forms.Label LblData;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtSalario;
        private System.Windows.Forms.TextBox TxtData;
        private System.Windows.Forms.Button BtnMensalista1;
        private System.Windows.Forms.Button BtnMensalista;
    }
}
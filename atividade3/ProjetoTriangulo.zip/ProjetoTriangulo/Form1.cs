﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTriangulo
{
    public partial class Form1 : Form

    {
        double LadoA, LadoB, LadoC;

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            textBoxLadoA.Clear();
            textBoxLadoB.Clear();
            textBoxLadoC.Clear();
            textBoxLadoA.Focus();
        }

        private void TextBoxLadoA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBoxLadoB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBoxLadoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }



        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonCalc_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(textBoxLadoA.Text, out LadoA) &&
                Double.TryParse(textBoxLadoB.Text, out LadoB) &&
                Double.TryParse(textBoxLadoC.Text, out LadoC))

            {
                if (LadoA < (LadoB + LadoC) && (LadoA > Math.Abs(LadoB - LadoC)) &&
                   LadoB < (LadoA + LadoC) && (LadoB > Math.Abs(LadoA - LadoB)) &&
                   LadoC < (LadoA + LadoB) && (LadoC > Math.Abs(LadoA - LadoC)))
                {
                    if (LadoA == LadoB && LadoB == LadoC)
                    {
                        MessageBox.Show("Triangulo Equilatero");
                    }
                    else

                    if (LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                    {
                        MessageBox.Show("Triangulo Isóceles");
                    }
                    else
                        MessageBox.Show("Triangulo Escaleno");


                }
                else
                {
                    MessageBox.Show("Não é um triangulo");
                }
            }


            else
                MessageBox.Show("Número inválido!");
        }
    }
}


    



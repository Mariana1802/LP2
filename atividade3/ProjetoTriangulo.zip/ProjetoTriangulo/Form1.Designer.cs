﻿
namespace ProjetoTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxLadoA = new System.Windows.Forms.TextBox();
            this.textBoxLadoB = new System.Windows.Forms.TextBox();
            this.textBoxLadoC = new System.Windows.Forms.TextBox();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Lado A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Lado B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(58, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Lado C";
            // 
            // textBoxLadoA
            // 
            this.textBoxLadoA.Location = new System.Drawing.Point(163, 48);
            this.textBoxLadoA.Name = "textBoxLadoA";
            this.textBoxLadoA.Size = new System.Drawing.Size(100, 20);
            this.textBoxLadoA.TabIndex = 6;
            this.textBoxLadoA.AcceptsTabChanged += new System.EventHandler(this.BtnLimp_Click);
            // 
            // textBoxLadoB
            // 
            this.textBoxLadoB.Location = new System.Drawing.Point(163, 114);
            this.textBoxLadoB.Name = "textBoxLadoB";
            this.textBoxLadoB.Size = new System.Drawing.Size(100, 20);
            this.textBoxLadoB.TabIndex = 7;
            // 
            // textBoxLadoC
            // 
            this.textBoxLadoC.Location = new System.Drawing.Point(163, 172);
            this.textBoxLadoC.Name = "textBoxLadoC";
            this.textBoxLadoC.Size = new System.Drawing.Size(100, 20);
            this.textBoxLadoC.TabIndex = 8;
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(61, 255);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(75, 23);
            this.buttonCalc.TabIndex = 9;
            this.buttonCalc.Text = "Calcular ";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.ButtonCalc_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.Location = new System.Drawing.Point(209, 255);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(75, 23);
            this.BtnLimp.TabIndex = 10;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.textBoxLadoC);
            this.Controls.Add(this.textBoxLadoB);
            this.Controls.Add(this.textBoxLadoA);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxLadoB;
        private System.Windows.Forms.TextBox textBoxLadoC;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.Button BtnLimp;
        private System.Windows.Forms.TextBox textBoxLadoA;
    }
}


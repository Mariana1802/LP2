﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023010
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnverificar_Click(object sender, EventArgs e)
        {

            double[,] Valores = new double[10, 4];
            double[] TotalMes = new double[10];
            string valor;
            double totalMeses = 0;


            for (int s = 0; s < 10; s++)
            {
                for (int m = 0; m < 4; m++)
                {
                    valor = Interaction.InputBox("Digite o valor da semana " + (m + 1) + " Do Mês: " + (s + 1), "Entrada de dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Digite um valor válido");
                        m--;
                    }
                    else if (double.TryParse(valor, out Valores[s, m]))
                    {
                        double.TryParse(valor, out Valores[s, m]);
                    }
                    else
                    {
                        MessageBox.Show("Digite um valor válido!");
                        m--;
                    }
                }
            }


            for (int s = 0; s < 10; s++)
            {
                for (int m = 0; m < 4; m++)
                {
                    TotalMes[s] = TotalMes[s] + Valores[s, m];
                }
                totalMeses = totalMeses + TotalMes[s];
            }

            for (int s = 0; s < 10; s++)
            {
                for (int m = 0; m < 4; m++)
                {
                    listaMeses.Items.Add("Total do Mês: " + (s + 1) + " Semana: " + (m + 1) + ": R$" + Valores[s, m].ToString("N2"));
                }
                listaMeses.Items.Add(">>Total Mês: R$" + TotalMes[s].ToString("N2"));
                listaMeses.Items.Add("--------------");
            }
            listaMeses.Items.Add("Total Geral: R$" + totalMeses.ToString("N2"));
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

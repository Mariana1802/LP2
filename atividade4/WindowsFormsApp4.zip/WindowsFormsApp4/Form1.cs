﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnverificadesconto_Click(object sender, EventArgs e)
        {
            lblmensagem.Visible = true;

            double descontoInss = 0;
            double descontoIrff = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            int NumerodeFilhos = 0;

            if ((txtNome.Text == "") || (txtNome.Text.Length < 5))

                MessageBox.Show("Nome Inválido !");

            else if (double.TryParse(mskbxSaláriobruto.Text, out salarioBruto))
            {
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaInss.Text = "7.65%";
                    descontoInss = 0.0765 * salarioBruto;
                }

                else if (salarioBruto <= 1050)
                {
                    txtAliquotaInss.Text = "8.65%";
                    descontoInss = 0.0865 * salarioBruto;

                }

                else if (salarioBruto <= 1400.77)
                {
                    txtAliquotaInss.Text = "9%";
                    descontoInss = 0.09 * salarioBruto;
                }

                else if (salarioBruto <= 2801.56)
                {
                    txtAliquotaInss.Text = "11%";
                    descontoInss = 0.11 * salarioBruto;
                }
                else
                {
                    txtAliquotaInss.Text = "isento";
                    descontoInss = 0;


                }
                txtDescontoInss.Text = descontoInss.ToString("N2");


                if (salarioBruto <= 1257.12)
                {
                    txtAliquotaIr.Text = "isento";
                    descontoIrff = 0;

                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliquotaIr.Text = "15%";
                    descontoIrff = 0.15 * salarioBruto;
                }
                else
                {
                    txtAliquotaIr.Text = "27.5%";
                    descontoIrff = 0.275 * salarioBruto;

                    ///aqui tinha que ser executado não importa o caso????
                }
                txtDescontoIr.Text = descontoIrff.ToString("N2");
                //


                int.TryParse(cbxNumeroFilhos.Text, out NumerodeFilhos);

                if (salarioBruto <= 435.52)
                {
                    txtSalarioFamilia.Text = "22.33";
                    salarioFamilia = 22.33 * NumerodeFilhos;

                }
                else if (salarioBruto <= 654.61)
                {
                    txtSalarioFamilia.Text = "15.74";
                    salarioFamilia = 15.74 * NumerodeFilhos;
                }
                else if (salarioBruto > 654.61)
                {

                    txtSalarioFamilia.Text = "0";
                    salarioFamilia = 0;
                }


                txtSalarioLiquido.Text = "0";
                salarioLiquido = salarioBruto - descontoIrff - descontoInss + salarioFamilia; //essa parte tinha que executar não importa o valor?

                txtSalarioLiquido.Text = salarioLiquido.ToString("N2");



                lblmensagem.Text = "Os descontos do salário ";

                if (rdbtnFeminino.Checked)
                    lblmensagem.Text = lblmensagem.Text + "da Sra " + txtNome.Text;
                else
                {
                    lblmensagem.Text = lblmensagem.Text + "da Sro " + txtNome.Text;

                    lblmensagem.Text = lblmensagem.Text + "que é ";
                }

                if (ckbxCasado.Checked)
                {

                    lblmensagem.Text = lblmensagem.Text + " casado ";

                    lblmensagem.Text = lblmensagem.Text + "e que tem ";

                    lblmensagem.Text = lblmensagem.Text + "filhos ";

                    lblmensagem.Text = lblmensagem.Text + "são: ";
                }

                else
                {

                    lblmensagem.Text = lblmensagem.Text + "solteiro ";

                    lblmensagem.Text = lblmensagem.Text + "e que tem ";

                    lblmensagem.Text = lblmensagem.Text + "filhos ";

                    lblmensagem.Text = lblmensagem.Text + "são: ";
                }


            }

        }
    }
} 
              
  
         
    

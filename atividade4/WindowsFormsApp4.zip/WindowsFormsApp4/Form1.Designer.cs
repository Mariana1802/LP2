﻿
namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.mskbxSaláriobruto = new System.Windows.Forms.MaskedTextBox();
            this.cbxNumeroFilhos = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtnFeminino = new System.Windows.Forms.RadioButton();
            this.rdbtnMasculino = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.lblmensagem = new System.Windows.Forms.Label();
            this.btnverificadesconto = new System.Windows.Forms.Button();
            this.lblAliquotaInss = new System.Windows.Forms.Label();
            this.lblAliquotaIrff = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliquotaInss = new System.Windows.Forms.TextBox();
            this.txtAliquotaIr = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.txtDescontoInss = new System.Windows.Forms.TextBox();
            this.txtDescontoIr = new System.Windows.Forms.TextBox();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.lblDescontoIrff = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(22, 26);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(111, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário ";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(22, 78);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalBruto.TabIndex = 1;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(22, 137);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de filhos ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(160, 26);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(281, 20);
            this.txtNome.TabIndex = 3;
            // 
            // mskbxSaláriobruto
            // 
            this.mskbxSaláriobruto.Location = new System.Drawing.Point(160, 75);
            this.mskbxSaláriobruto.Mask = "00000.00";
            this.mskbxSaláriobruto.Name = "mskbxSaláriobruto";
            this.mskbxSaláriobruto.Size = new System.Drawing.Size(121, 20);
            this.mskbxSaláriobruto.TabIndex = 4;
            // 
            // cbxNumeroFilhos
            // 
            this.cbxNumeroFilhos.FormattingEnabled = true;
            this.cbxNumeroFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbxNumeroFilhos.Location = new System.Drawing.Point(160, 137);
            this.cbxNumeroFilhos.Name = "cbxNumeroFilhos";
            this.cbxNumeroFilhos.Size = new System.Drawing.Size(121, 21);
            this.cbxNumeroFilhos.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtnMasculino);
            this.groupBox1.Controls.Add(this.rdbtnFeminino);
            this.groupBox1.Location = new System.Drawing.Point(467, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(166, 79);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdbtnFeminino
            // 
            this.rdbtnFeminino.AutoSize = true;
            this.rdbtnFeminino.Checked = true;
            this.rdbtnFeminino.Location = new System.Drawing.Point(56, 22);
            this.rdbtnFeminino.Name = "rdbtnFeminino";
            this.rdbtnFeminino.Size = new System.Drawing.Size(67, 17);
            this.rdbtnFeminino.TabIndex = 0;
            this.rdbtnFeminino.TabStop = true;
            this.rdbtnFeminino.Text = "Feminino";
            this.rdbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // rdbtnMasculino
            // 
            this.rdbtnMasculino.AutoSize = true;
            this.rdbtnMasculino.Location = new System.Drawing.Point(56, 56);
            this.rdbtnMasculino.Name = "rdbtnMasculino";
            this.rdbtnMasculino.Size = new System.Drawing.Size(73, 17);
            this.rdbtnMasculino.TabIndex = 1;
            this.rdbtnMasculino.Text = "Masculino";
            this.rdbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(530, 134);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbxCasado.TabIndex = 7;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // lblmensagem
            // 
            this.lblmensagem.AutoSize = true;
            this.lblmensagem.Location = new System.Drawing.Point(12, 203);
            this.lblmensagem.Name = "lblmensagem";
            this.lblmensagem.Size = new System.Drawing.Size(35, 13);
            this.lblmensagem.TabIndex = 8;
            this.lblmensagem.Text = "label1";
            // 
            // btnverificadesconto
            // 
            this.btnverificadesconto.Location = new System.Drawing.Point(321, 243);
            this.btnverificadesconto.Name = "btnverificadesconto";
            this.btnverificadesconto.Size = new System.Drawing.Size(120, 23);
            this.btnverificadesconto.TabIndex = 9;
            this.btnverificadesconto.Text = "Verificar Desconto ";
            this.btnverificadesconto.UseVisualStyleBackColor = true;
            this.btnverificadesconto.Click += new System.EventHandler(this.btnverificadesconto_Click);
            // 
            // lblAliquotaInss
            // 
            this.lblAliquotaInss.AutoSize = true;
            this.lblAliquotaInss.Location = new System.Drawing.Point(22, 294);
            this.lblAliquotaInss.Name = "lblAliquotaInss";
            this.lblAliquotaInss.Size = new System.Drawing.Size(67, 13);
            this.lblAliquotaInss.TabIndex = 10;
            this.lblAliquotaInss.Text = "Aliquota Inss";
            // 
            // lblAliquotaIrff
            // 
            this.lblAliquotaIrff.AutoSize = true;
            this.lblAliquotaIrff.Location = new System.Drawing.Point(22, 333);
            this.lblAliquotaIrff.Name = "lblAliquotaIrff";
            this.lblAliquotaIrff.Size = new System.Drawing.Size(60, 13);
            this.lblAliquotaIrff.TabIndex = 11;
            this.lblAliquotaIrff.Text = "Aliquota Irff";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(22, 364);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(74, 13);
            this.lblSalFamilia.TabIndex = 12;
            this.lblSalFamilia.Text = "Salário Familia";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(22, 401);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(76, 13);
            this.lblSalLiquido.TabIndex = 13;
            this.lblSalLiquido.Text = "Salário Liquido";
            // 
            // txtAliquotaInss
            // 
            this.txtAliquotaInss.Enabled = false;
            this.txtAliquotaInss.Location = new System.Drawing.Point(111, 294);
            this.txtAliquotaInss.Name = "txtAliquotaInss";
            this.txtAliquotaInss.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaInss.TabIndex = 14;
            // 
            // txtAliquotaIr
            // 
            this.txtAliquotaIr.Enabled = false;
            this.txtAliquotaIr.Location = new System.Drawing.Point(111, 333);
            this.txtAliquotaIr.Name = "txtAliquotaIr";
            this.txtAliquotaIr.Size = new System.Drawing.Size(100, 20);
            this.txtAliquotaIr.TabIndex = 15;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Enabled = false;
            this.txtSalarioFamilia.Location = new System.Drawing.Point(111, 364);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioFamilia.TabIndex = 16;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Enabled = false;
            this.txtSalarioLiquido.Location = new System.Drawing.Point(111, 401);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioLiquido.TabIndex = 17;
            // 
            // txtDescontoInss
            // 
            this.txtDescontoInss.Enabled = false;
            this.txtDescontoInss.Location = new System.Drawing.Point(642, 305);
            this.txtDescontoInss.Name = "txtDescontoInss";
            this.txtDescontoInss.Size = new System.Drawing.Size(111, 20);
            this.txtDescontoInss.TabIndex = 18;
            // 
            // txtDescontoIr
            // 
            this.txtDescontoIr.Enabled = false;
            this.txtDescontoIr.Location = new System.Drawing.Point(642, 347);
            this.txtDescontoIr.Name = "txtDescontoIr";
            this.txtDescontoIr.Size = new System.Drawing.Size(111, 20);
            this.txtDescontoIr.TabIndex = 19;
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Location = new System.Drawing.Point(561, 308);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(75, 13);
            this.lblDescontoInss.TabIndex = 20;
            this.lblDescontoInss.Text = "Desconto Inss";
            // 
            // lblDescontoIrff
            // 
            this.lblDescontoIrff.AutoSize = true;
            this.lblDescontoIrff.Location = new System.Drawing.Point(561, 354);
            this.lblDescontoIrff.Name = "lblDescontoIrff";
            this.lblDescontoIrff.Size = new System.Drawing.Size(68, 13);
            this.lblDescontoIrff.TabIndex = 21;
            this.lblDescontoIrff.Text = "Desconto Irff";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 450);
            this.Controls.Add(this.lblDescontoIrff);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.txtDescontoIr);
            this.Controls.Add(this.txtDescontoInss);
            this.Controls.Add(this.txtSalarioLiquido);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliquotaIr);
            this.Controls.Add(this.txtAliquotaInss);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliquotaIrff);
            this.Controls.Add(this.lblAliquotaInss);
            this.Controls.Add(this.btnverificadesconto);
            this.Controls.Add(this.lblmensagem);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbxNumeroFilhos);
            this.Controls.Add(this.mskbxSaláriobruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.MaskedTextBox mskbxSaláriobruto;
        private System.Windows.Forms.ComboBox cbxNumeroFilhos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnMasculino;
        private System.Windows.Forms.RadioButton rdbtnFeminino;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label lblmensagem;
        private System.Windows.Forms.Button btnverificadesconto;
        private System.Windows.Forms.Label lblAliquotaInss;
        private System.Windows.Forms.Label lblAliquotaIrff;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliquotaInss;
        private System.Windows.Forms.TextBox txtAliquotaIr;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.TextBox txtDescontoInss;
        private System.Windows.Forms.TextBox txtDescontoIr;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Label lblDescontoIrff;
    }
}


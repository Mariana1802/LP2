﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            {
                int[] vetor = new int[20];
                string auxiliar = "";
                string saida = "";

                for (var i = 0; i < vetor.Length; i++)
                {
                    auxiliar = Interaction.InputBox("Digite o número" + (i + 1).ToString(), "Entrada de Dados");

                    if (auxiliar == "")
                        break;


                    if (!int.TryParse(auxiliar, out vetor[i]))
                    {
                        MessageBox.Show("Número inválido");
                        i--;

                    }

                    else
                    {
                        saida = vetor[i] + "\n" + saida;
                    }
                }
                MessageBox.Show(saida);

            }


        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string Auxiliar = "";
            string saida = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                Auxiliar = Interaction.InputBox("Digite o número na posição " + (i + 1).ToString(), "Entrada de Dados");

                if (!int.TryParse(Auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            foreach (int C in vetor)
            {
                saida += C + "\n";
            }

            MessageBox.Show(saida);
        }

        private void BtnExercicio3_Click(object sender, EventArgs e)
        {
            int[] VetQtd = new int[10];
            double[] VetPreco = new double[10];
            string Aux = "";
            double Faturamento = 0;
            int i = 0;
            //recebe valor
            for (i = 0; i < VetPreco.Length; i++) // controla a posição
            {
                do
                {
                    Aux = Interaction.InputBox("Quantidade de Produtos no Cod: " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Aux == "")
                        break;

                    if (!int.TryParse(Aux, out VetQtd[i]))
                    {
                        MessageBox.Show("Número inválido!");
                    }
                } while (!(VetQtd[i] > 0));

                Aux = "";
                do
                {
                    Aux = Interaction.InputBox("Digite o Preço R$ do produtos de Cod: " +
                        (i + 1).ToString(), "Entrada de Dados");

                    if (Aux == "")
                        break;

                    if (!double.TryParse(Aux, out VetPreco[i]))
                    {
                        MessageBox.Show("Valor inválido!");
                    }
                } while (!(VetPreco[i] > 0));
            }

            for (i = 0; i < VetQtd.Length; i++)
            {
                Faturamento += VetQtd[i] * VetPreco[i];
            }

            MessageBox.Show("O Faturamento Mensal é: " + Faturamento.ToString("C2"));

        }

        private void btxExercicio4_Click(object sender, EventArgs e)
        {
            if (rbtnA.Checked || rbtnB.Checked || rbtnC.Checked || rbtnD.Checked)
            {
                if (rbtnC.Checked)
                {
                    MessageBox.Show("Parabéns você acertou");
                }
                else
                    MessageBox.Show("Tente Novamente");
            }
            else
                MessageBox.Show("Escolha uma opção");
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            String Saida1 = "\n";
            String Saida2 = "\n";

            ArrayList Aluno = new ArrayList();
            Aluno.Add("Ana");
            Aluno.Add("André");
            Aluno.Add("Débora");
            Aluno.Add("Fátima");
            Aluno.Add("João");
            Aluno.Add("Janete");
            Aluno.Add("Otávio");
            Aluno.Add("Marcelo");
            Aluno.Add("Pedro");
            Aluno.Add("Thais");

            foreach (string Nomes in Aluno)
                Saida1 += Nomes + "\n"; // exibir lista dos alunos // 

            Aluno.Remove("Otávio");


            foreach (string Nomes in Aluno)
                Saida2 += Nomes + "\n"; // exibir lista retirando aluno// 

            MessageBox.Show("Lista de Alunos: " + Saida1 + "\n\n" + "Lista Atualizada: " + Saida2);

        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            string Auxiliar = "";
            double Media;

            for (int i = 0; i < 20; i++)
            {
                Media = 0;
                for (int c = 0; c < 3; c++)
                {
                    Auxiliar = Interaction.InputBox("Aluno " + (i + 1).ToString() + "-" + " informe a " +
                        (c + 1).ToString() + "° Nota", "Calcula a Média");

                    if (Auxiliar == "")
                        break;

                    if (!double.TryParse(Auxiliar, out Notas[i, c]))
                    {
                        MessageBox.Show("Número inválido!");
                        c--;
                    }

                    Media += Notas[i, c];
                }

                ListaMédias.Items.Add("Aluno " + (i + 1) + ":" + "Media: " + Math.Round(Media / 3, 2) + ("\n"));



            }

        }

        private void btnExercicio8_Click(object sender, EventArgs e)
        {
            btnExercicio1.Visible = false;
            btnExercicio2.Visible = false;
            BtnExercicio3.Visible = false;
            btnExercicio4.Visible = false;
            btnExercicio5.Visible = false;
            btnExercicio6.Visible = false;


            ListaNomes.Visible = true;


            string Auxiliar = "";
            int N = 0;
            int Comprimento;


            do
            {
                Auxiliar = Interaction.InputBox("Permitido apenas Número de 0 a 9" + "\n para 10 informe 0",
                    "Informe o último digito do seu RA");


                if (Auxiliar == "")
                    break;

                if (!int.TryParse(Auxiliar, out N))
                {
                    MessageBox.Show("Número inválido!");
                    N = 11;

                }
            } while ((!(N >= 0) || !(N < 10)));

            if (N == 0)
                N = 10;

            for (var i = 0; i < N; i++)
            {
                Comprimento = 0;
                Auxiliar = Interaction.InputBox("Digite o nome na posição: " +
                    (i + 1).ToString(), "Entrada de Dados");

                if (Auxiliar == "")
                    break;

                if (Auxiliar.Length < 8)
                {
                    MessageBox.Show("Nome inválido!");
                    i--;
                }
                else
                {
                    Comprimento = (Auxiliar.Replace(" ", "")).Length;
                    ListaNomes.Items.Add("O nome: " + Auxiliar + ":" + " tem " + Comprimento + " caracteres" + ("\n"));
                }
            }
        }
    }
}




























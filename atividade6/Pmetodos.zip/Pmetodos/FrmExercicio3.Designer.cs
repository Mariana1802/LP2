﻿
namespace Pmetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.BtnRemove1 = new System.Windows.Forms.Button();
            this.btnRemove2 = new System.Windows.Forms.Button();
            this.btnInverte = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Location = new System.Drawing.Point(25, 23);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra1.TabIndex = 0;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Location = new System.Drawing.Point(25, 72);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra2.TabIndex = 1;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(100, 16);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(184, 20);
            this.txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(100, 72);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(184, 20);
            this.txtPalavra2.TabIndex = 3;
            // 
            // BtnRemove1
            // 
            this.BtnRemove1.Location = new System.Drawing.Point(12, 169);
            this.BtnRemove1.Name = "BtnRemove1";
            this.BtnRemove1.Size = new System.Drawing.Size(114, 36);
            this.BtnRemove1.TabIndex = 4;
            this.BtnRemove1.Text = "Remove 1° do 2°";
            this.BtnRemove1.UseVisualStyleBackColor = true;
            this.BtnRemove1.Click += new System.EventHandler(this.BtnRemove1_Click);
            // 
            // btnRemove2
            // 
            this.btnRemove2.Location = new System.Drawing.Point(170, 169);
            this.btnRemove2.Name = "btnRemove2";
            this.btnRemove2.Size = new System.Drawing.Size(114, 36);
            this.btnRemove2.TabIndex = 5;
            this.btnRemove2.Text = "Remove 1° do 2° (replace)";
            this.btnRemove2.UseVisualStyleBackColor = true;
            this.btnRemove2.Click += new System.EventHandler(this.btnRemove2_Click);
            // 
            // btnInverte
            // 
            this.btnInverte.Location = new System.Drawing.Point(312, 169);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(114, 36);
            this.btnInverte.TabIndex = 6;
            this.btnInverte.Text = "Inverte 1°";
            this.btnInverte.UseVisualStyleBackColor = true;
            this.btnInverte.Click += new System.EventHandler(this.btnInverte_Click);
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(502, 259);
            this.Controls.Add(this.btnInverte);
            this.Controls.Add(this.btnRemove2);
            this.Controls.Add(this.BtnRemove1);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPalavra1;
        private System.Windows.Forms.Label LblPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button BtnRemove1;
        private System.Windows.Forms.Button btnRemove2;
        private System.Windows.Forms.Button btnInverte;
    }
}
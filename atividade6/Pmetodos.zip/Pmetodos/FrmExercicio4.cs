﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnquantidadeCaracteres_Click(object sender, EventArgs e)

        {
            int contador = 0;
            int i = 0;

            if ((richTxtCaixadeTexto.Text == ""))
                MessageBox.Show("Conteúdo Vazio");

            else
            {
                string Texto = richTxtCaixadeTexto.Text;
                int Quantidade = richTxtCaixadeTexto.Text.Length;


                for (i = 0; i < Quantidade; i++) 
                    if (char.IsNumber(Texto[i]))
                    {
                    contador++;
                    }

                if (contador > 0)
                    MessageBox.Show("A quantidade de caractere numérico é: " + contador);


                else
                    MessageBox.Show("Nenhum caractere numérico encontrado");
            }

        

        }

        private void btnPrimeiroCharBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int posicão = 0; 
            if ((richTxtCaixadeTexto.Text == ""))
                MessageBox.Show("Conteúdo Vazio");

            else
            {
                string Texto = richTxtCaixadeTexto.Text;
                while (i < Texto.Length)
                {
                    if (!char.IsWhiteSpace(Texto[i]))
                    {
                        i++;
                    }
                    else
                    {
                        posicão = i;
                        break;
                    }
                }

                if (posicão > 0)

                    MessageBox.Show("A posição do 1° caractere branco é: " + posicão);


                else
                    MessageBox.Show("Nenhum caractere branco encontrado");
            } 
        }

        private void btnQuantCaracteresAlfa_Click(object sender, EventArgs e)
        {
            int contador = 0;
            if (richTxtCaixadeTexto.Text == "") ;
            else
            {
                foreach(char i in richTxtCaixadeTexto.Text)
                    if (char.IsLetter(i))
                    {
                        contador++;
                    }

                if (contador > 0)
                    MessageBox.Show("A quantidade de caractere alfabético é: " + contador);


                else
                    MessageBox.Show("Nenhum caractere alfabético encontrado");
            }
        }
    }
 }

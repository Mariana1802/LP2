﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSortear_Click(object sender, EventArgs e)

        {
            int Numero1 = Convert.ToInt32(txtNumero1.Text);
            int Numero2 = Convert.ToInt32(txtNumero2.Text);





                Random random = new Random();

            int Num = random.Next(Numero1, Numero2);

            MessageBox.Show("O Número sorteado é: ", Num.ToString());
            







            

        }
    }
}

﻿
namespace Pmetodos
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtCaixadeTexto = new System.Windows.Forms.RichTextBox();
            this.btnquantidadeCaracteres = new System.Windows.Forms.Button();
            this.btnPrimeiroCharBranco = new System.Windows.Forms.Button();
            this.btnQuantCaracteresAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTxtCaixadeTexto
            // 
            this.richTxtCaixadeTexto.Location = new System.Drawing.Point(89, 42);
            this.richTxtCaixadeTexto.Name = "richTxtCaixadeTexto";
            this.richTxtCaixadeTexto.Size = new System.Drawing.Size(377, 96);
            this.richTxtCaixadeTexto.TabIndex = 0;
            this.richTxtCaixadeTexto.Text = "";
            // 
            // btnquantidadeCaracteres
            // 
            this.btnquantidadeCaracteres.Location = new System.Drawing.Point(89, 194);
            this.btnquantidadeCaracteres.Name = "btnquantidadeCaracteres";
            this.btnquantidadeCaracteres.Size = new System.Drawing.Size(108, 63);
            this.btnquantidadeCaracteres.TabIndex = 1;
            this.btnquantidadeCaracteres.Text = "Quantidade de Caracteres Númericos";
            this.btnquantidadeCaracteres.UseVisualStyleBackColor = true;
            this.btnquantidadeCaracteres.Click += new System.EventHandler(this.btnquantidadeCaracteres_Click);
            // 
            // btnPrimeiroCharBranco
            // 
            this.btnPrimeiroCharBranco.Location = new System.Drawing.Point(230, 194);
            this.btnPrimeiroCharBranco.Name = "btnPrimeiroCharBranco";
            this.btnPrimeiroCharBranco.Size = new System.Drawing.Size(104, 63);
            this.btnPrimeiroCharBranco.TabIndex = 2;
            this.btnPrimeiroCharBranco.Text = "1° Caractere Branco ";
            this.btnPrimeiroCharBranco.UseVisualStyleBackColor = true;
            this.btnPrimeiroCharBranco.Click += new System.EventHandler(this.btnPrimeiroCharBranco_Click);
            // 
            // btnQuantCaracteresAlfa
            // 
            this.btnQuantCaracteresAlfa.Location = new System.Drawing.Point(369, 194);
            this.btnQuantCaracteresAlfa.Name = "btnQuantCaracteresAlfa";
            this.btnQuantCaracteresAlfa.Size = new System.Drawing.Size(97, 63);
            this.btnQuantCaracteresAlfa.TabIndex = 3;
            this.btnQuantCaracteresAlfa.Text = "Quantidade de Caracteres Alfábéticos";
            this.btnQuantCaracteresAlfa.UseVisualStyleBackColor = true;
            this.btnQuantCaracteresAlfa.Click += new System.EventHandler(this.btnQuantCaracteresAlfa_Click);
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQuantCaracteresAlfa);
            this.Controls.Add(this.btnPrimeiroCharBranco);
            this.Controls.Add(this.btnquantidadeCaracteres);
            this.Controls.Add(this.richTxtCaixadeTexto);
            this.Name = "FrmExercicio4";
            this.Text = "FrmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtCaixadeTexto;
        private System.Windows.Forms.Button btnquantidadeCaracteres;
        private System.Windows.Forms.Button btnPrimeiroCharBranco;
        private System.Windows.Forms.Button btnQuantCaracteresAlfa;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppPesoIdeal
{
    public partial class Form1 : Form
    {

        double altura, peso, pesoIdeal;

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            maskedAltura.Clear();
            maskedPeso.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(maskedAltura.Text, out altura) &&
                   double.TryParse(maskedPeso.Text, out peso)) ;
            {

                if (rdbtnFem.Checked)

                {
                    pesoIdeal = (62.1 * altura) - 44.7;
                    pesoIdeal = Math.Round(pesoIdeal, 2);
                }
                else
                {
                    pesoIdeal = (72.7 * altura) - 58;
                    pesoIdeal = Math.Round(pesoIdeal, 2);
                }

                if (peso > pesoIdeal)
                    MessageBox.Show("Regime Obrigatório Já !");
                else

                if (peso < pesoIdeal)

                    MessageBox.Show("Coma bastante massas e doces!");
                else

                    MessageBox.Show("Você está com peso ideal!");
            }

        }
    }
}
      
           
          

        
     

   

﻿
namespace AppPesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rdbtnFem = new System.Windows.Forms.RadioButton();
            this.rdbtnMasc = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtCalc = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.maskedAltura = new System.Windows.Forms.MaskedTextBox();
            this.maskedPeso = new System.Windows.Forms.MaskedTextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Altura";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Peso";
            // 
            // rdbtnFem
            // 
            this.rdbtnFem.AutoSize = true;
            this.rdbtnFem.Location = new System.Drawing.Point(37, 33);
            this.rdbtnFem.Name = "rdbtnFem";
            this.rdbtnFem.Size = new System.Drawing.Size(67, 17);
            this.rdbtnFem.TabIndex = 3;
            this.rdbtnFem.TabStop = true;
            this.rdbtnFem.Text = "Feminino";
            this.rdbtnFem.UseVisualStyleBackColor = true;
            // 
            // rdbtnMasc
            // 
            this.rdbtnMasc.AutoSize = true;
            this.rdbtnMasc.Location = new System.Drawing.Point(37, 80);
            this.rdbtnMasc.Name = "rdbtnMasc";
            this.rdbtnMasc.Size = new System.Drawing.Size(73, 17);
            this.rdbtnMasc.TabIndex = 4;
            this.rdbtnMasc.TabStop = true;
            this.rdbtnMasc.Text = "Masculino";
            this.rdbtnMasc.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtnMasc);
            this.groupBox1.Controls.Add(this.rdbtnFem);
            this.groupBox1.Location = new System.Drawing.Point(310, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 131);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // BtCalc
            // 
            this.BtCalc.Location = new System.Drawing.Point(42, 259);
            this.BtCalc.Name = "BtCalc";
            this.BtCalc.Size = new System.Drawing.Size(75, 23);
            this.BtCalc.TabIndex = 6;
            this.BtCalc.Text = "Calcular";
            this.BtCalc.UseVisualStyleBackColor = true;
            this.BtCalc.Click += new System.EventHandler(this.Button1_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.Location = new System.Drawing.Point(167, 259);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(75, 23);
            this.BtnLimp.TabIndex = 7;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(310, 259);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // maskedAltura
            // 
            this.maskedAltura.Location = new System.Drawing.Point(113, 48);
            this.maskedAltura.Mask = "0.00";
            this.maskedAltura.Name = "maskedAltura";
            this.maskedAltura.Size = new System.Drawing.Size(100, 20);
            this.maskedAltura.TabIndex = 9;
            // 
            // maskedPeso
            // 
            this.maskedPeso.Location = new System.Drawing.Point(113, 106);
            this.maskedPeso.Mask = "000.00";
            this.maskedPeso.Name = "maskedPeso";
            this.maskedPeso.Size = new System.Drawing.Size(100, 20);
            this.maskedPeso.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.maskedPeso);
            this.Controls.Add(this.maskedAltura);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.BtCalc);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdbtnFem;
        private System.Windows.Forms.RadioButton rdbtnMasc;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtCalc;
        private System.Windows.Forms.Button BtnLimp;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.MaskedTextBox maskedAltura;
        private System.Windows.Forms.MaskedTextBox maskedPeso;
    }
}

